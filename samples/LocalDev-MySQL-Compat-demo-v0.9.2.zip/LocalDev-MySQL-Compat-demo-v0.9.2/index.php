<?php
declare(strict_types=1);
$config = require __DIR__ . '/config.php';
$db = $config['db'];
$dsn = sprintf('mysql:host=%s;port=3306;dbname=%s;charset=%s', $db['host'], $db['name'], $db['charset']);
try {
    $pdo = new PDO($dsn, $db['user'], $db['pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    $driver = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
    $version = (string)$pdo->query('SELECT VERSION()')->fetchColumn();
    $database = (string)$pdo->query('SELECT DATABASE()')->fetchColumn();
    $stmt = $pdo->prepare('SELECT id,name,downloads FROM apps WHERE id=?');
    $stmt->execute([1]);
    $row = $stmt->fetch();
    $pdo->prepare("INSERT INTO settings(`key`,value) VALUES(?,?) ON DUPLICATE KEY UPDATE value=VALUES(value)")
        ->execute(['compat_probe', date('c')]);
    $columns = $pdo->query('SHOW COLUMNS FROM apps')->fetchAll();
    $ok = $driver === 'mysql' && is_array($row) && count($columns) >= 3;
} catch (Throwable $e) {
    $ok = false;
    $error = $e->getMessage();
}
?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>LocalDev MySQL Compatibility Test</title><style>body{font-family:system-ui;background:#06111b;color:#edf7ff;padding:28px}.card{padding:18px;margin:12px 0;background:#102331;border-radius:18px}.ok{color:#19ded8}.bad{color:#ff8098}code{color:#19ded8}</style></head><body>
<h1>LocalDev MySQL Protocol <?= $ok ? '✅' : '❌' ?></h1>
<?php if($ok): ?>
<div class="card"><b class="ok">PDO driver:</b> <?= htmlspecialchars($driver) ?></div>
<div class="card"><b>Server:</b> <?= htmlspecialchars($version) ?></div>
<div class="card"><b>Database:</b> <?= htmlspecialchars($database) ?></div>
<div class="card"><b>Native prepared SELECT:</b> <?= htmlspecialchars($row['name'] ?? '') ?> — <?= (int)($row['downloads'] ?? 0) ?> downloads</div>
<div class="card"><b>SHOW COLUMNS:</b> <?= count($columns) ?> columns</div>
<p>Config awal project memakai <code>localhost</code>. LocalDev membuat local TCP profile pada copy project yang di-import.</p>
<?php else: ?><div class="card bad"><?= htmlspecialchars($error ?? 'Unknown error') ?></div><?php endif; ?>
</body></html>
