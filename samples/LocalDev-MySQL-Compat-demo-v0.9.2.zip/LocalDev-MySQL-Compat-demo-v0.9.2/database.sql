CREATE TABLE `apps` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(120) NOT NULL,
  `downloads` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `apps` (`id`,`name`,`downloads`,`created_at`) VALUES
(1,'LocalDev',100,NOW()),
(2,'MySQL Protocol Demo',25,NOW());

CREATE TABLE `settings` (
  `key` varchar(120) NOT NULL,
  `value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE `apps` ADD PRIMARY KEY (`id`);
ALTER TABLE `apps` MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
ALTER TABLE `settings` ADD PRIMARY KEY (`key`);
