LocalDev v0.9.2 MySQL protocol validation project.

Expected flow:
1. Import ZIP.
2. Run -> Setup & Run.
3. LocalDev imports database.sql.
4. LocalDev backs up config.php and changes localhost -> 127.0.0.1 only in the imported copy.
5. PDO MySQL connects to LocalDevDB on TCP 3306.
6. Page must show PDO driver=mysql and prepared statement result.
