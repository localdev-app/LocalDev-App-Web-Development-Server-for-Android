<?php
return [
    'db' => [
        // Deliberately localhost: LocalDev v0.9.2 should back this file up
        // and use 127.0.0.1 in the imported copy so PDO uses TCP.
        'host' => 'localhost',
        'name' => 'localdev',
        'user' => 'localdev',
        'pass' => 'localdev',
        'charset' => 'utf8mb4',
    ],
    // Deliberately looks like production. LocalDev should keep preview local.
    'site_url' => 'https://production.example',
];
