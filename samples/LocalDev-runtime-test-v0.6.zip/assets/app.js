function localDevJsTest(){
  const el=document.getElementById('js-status');
  el.textContent='JavaScript bekerja · '+new Date().toLocaleTimeString();
  console.log('LocalDev v0.6 JavaScript OK');
}
