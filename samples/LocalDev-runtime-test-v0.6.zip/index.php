<?php
header('Content-Type: text/html; charset=UTF-8');
session_start();
$_SESSION['visits'] = (int)($_SESSION['visits'] ?? 0) + 1;

$checks = [
    'PDO SQLite' => extension_loaded('pdo_sqlite'),
    'SQLite3' => extension_loaded('sqlite3'),
    'cURL' => extension_loaded('curl'),
    'OpenSSL' => extension_loaded('openssl'),
    'ZIP' => extension_loaded('zip'),
];

$dbPath = __DIR__ . '/demo.sqlite';
$sqliteMessage = 'Belum dites';
try {
    $db = new PDO('sqlite:' . $dbPath);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->exec('CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY, text TEXT NOT NULL)');
    $db->exec("INSERT INTO notes(text) VALUES ('LocalDev v0.6 OK')");
    $count = (int)$db->query('SELECT COUNT(*) FROM notes')->fetchColumn();
    $sqliteMessage = "SQLite write/read OK — rows: {$count}";
} catch (Throwable $e) {
    $sqliteMessage = 'SQLite ERROR: ' . $e->getMessage();
}

$opensslMessage = function_exists('openssl_random_pseudo_bytes')
    ? bin2hex(openssl_random_pseudo_bytes(8))
    : 'OpenSSL function tidak tersedia';

$zipMessage = 'ZIP belum tersedia';
if (class_exists('ZipArchive')) {
    $zipPath = __DIR__ . '/demo.zip';
    $z = new ZipArchive();
    if ($z->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
        $z->addFromString('hello.txt', 'LocalDev ZIP OK');
        $z->close();
        $zipMessage = 'ZipArchive create OK';
    }
}
$name = trim((string)($_POST['name'] ?? ''));
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>LocalDev Runtime Test v0.6</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<main>
  <div class="eyebrow">LOCALDEV PHP BRIDGE v0.6</div>
  <h1>LocalDev ✅</h1>
  <p>PHP <b><?= htmlspecialchars(PHP_VERSION) ?></b> · SAPI <code><?= htmlspecialchars(PHP_SAPI) ?></code></p>
  <div class="card success">Session bekerja · kunjungan: <b><?= (int)$_SESSION['visits'] ?></b></div>
  <div class="grid">
    <?php foreach ($checks as $label => $ok): ?>
      <div class="card <?= $ok ? 'success' : 'bad' ?>"><?= $ok ? '✓' : '✗' ?> <?= htmlspecialchars($label) ?></div>
    <?php endforeach; ?>
  </div>
  <div class="card"><?= htmlspecialchars($sqliteMessage) ?></div>
  <div class="card">OpenSSL: <code><?= htmlspecialchars($opensslMessage) ?></code></div>
  <div class="card"><?= htmlspecialchars($zipMessage) ?></div>
  <form method="post" class="card">
    <label>Tes POST</label>
    <input name="name" value="<?= htmlspecialchars($name) ?>" placeholder="Ketik nama">
    <button>Kirim</button>
    <?php if ($name !== ''): ?><p>POST diterima: <b><?= htmlspecialchars($name) ?></b></p><?php endif; ?>
  </form>
  <button type="button" onclick="localDevJsTest()">Tes JavaScript</button>
  <p id="js-status">JS belum dites</p>
</main>
<script src="assets/app.js"></script>
</body>
</html>
