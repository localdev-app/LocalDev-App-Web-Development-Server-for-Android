<?php
return array (
  'db' =>
  array (
    'host' => 'localhost',
    'name' => 'apknusa_demo',
    'user' => 'apknusa_demo',
    'pass' => 'demo_password',
    'charset' => 'utf8mb4',
  ),
  'site_url' => 'https://example.com',
);
