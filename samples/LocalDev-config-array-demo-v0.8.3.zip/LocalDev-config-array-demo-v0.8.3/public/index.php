<?php
$pdo = require dirname(__DIR__) . '/app/DB.php';
$rows = $pdo->query('SELECT id, name, downloads FROM apps ORDER BY id')->fetchAll();
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>LocalDev Config Array Demo</title><style>body{font-family:system-ui;background:#071018;color:#eef;padding:24px}.card{background:#102330;padding:16px;border-radius:16px;margin:12px 0}b{color:#20dfe0}</style></head><body><h1>Config Array Demo ✅</h1><p>config.php model hosting berhasil dipakai di LocalDev tanpa menghapus nilai production.</p><?php foreach($rows as $r): ?><div class="card"><b><?=htmlspecialchars($r['name'])?></b> — <?=intval($r['downloads'])?> downloads</div><?php endforeach; ?></body></html>
