CREATE TABLE `apps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `downloads` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO `apps` (`id`,`name`,`downloads`) VALUES
(1,'LocalDev',100),(2,'ApkNusa Demo',25),(3,'Config Array Patch',8);
