LocalDev v0.8.3 config-array compatibility demo.
Import ZIP -> Run -> Setup & Run.
LocalDev should import database.sql, patch config.php + app/DB.php with backups, then run public/index.php.
